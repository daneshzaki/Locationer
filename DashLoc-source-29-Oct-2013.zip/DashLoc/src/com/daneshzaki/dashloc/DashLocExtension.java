package com.daneshzaki.dashloc;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.google.android.apps.dashclock.api.DashClockExtension;
import com.google.android.apps.dashclock.api.ExtensionData;

/**
 * @author Danesh Zaki
 * 
 */
public class DashLocExtension extends DashClockExtension
{

	/*
	 * Initialize
	 */
	protected void onInitialize(boolean isReconnect)
	{
		this.setUpdateWhenScreenOn(true);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.google.android.apps.dashclock.api.DashClockExtension#onUpdateData
	 * (int)
	 */
	@Override
	protected void onUpdateData(int arg0)
	{

		// Acquire a reference to the system Location Manager
		LocationManager locationManager = (LocationManager) this
				.getSystemService(Context.LOCATION_SERVICE);

		// Register the listener with the Location Manager to receive location
		// updates
		locationManager.requestLocationUpdates(
				LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener()
				{
					@Override
					public void onLocationChanged(Location location)
					{
						// Called when a new location is found by the network
						// location provider.
						String latLong = String.valueOf(location.getLatitude())
								+ " " + String.valueOf(location.getLongitude());
						Log.i(this.getClass().getName(), latLong);

						Geocoder geocoder = new Geocoder(getBaseContext(),
								Locale.getDefault());
						Log.i("DashLoc", "locale " + Locale.getDefault());

						List<Address> addresses = null;

						try
						{
							addresses = geocoder.getFromLocation(
									location.getLatitude(),
									location.getLongitude(), 1);
						} catch (IOException e)
						{
							e.printStackTrace();
						}
						if (addresses != null && addresses.size() > 0)
						{
							Address address = addresses.get(0);
							// Format the first line of address (if available),
							// city, and country name.
							fullAddress = String.format(
									"%s, %s, %s",
									address.getMaxAddressLineIndex() > 0 ? address
											.getAddressLine(0) : "", address
											.getLocality(), address
											.getCountryName());
							
							Log.i("DashLoc", "address is " + address.getAddressLine(0));
							Log.i("DashLoc", "locality is " + address.getLocality());
							Log.i("DashLoc", "feature name is " + address.getFeatureName());
							area = address.getSubLocality();
							Log.i("DashLoc", "sub locality is " +area );
							Log.i("DashLoc", "SubAdminArea is " + address.getSubAdminArea());
							Log.i("DashLoc", "country is " + address.getCountryName());
							
						}

					}

					@Override
					public void onProviderDisabled(String provider)
					{

					}

					@Override
					public void onProviderEnabled(String provider)
					{

					}

					@Override
					public void onStatusChanged(String provider, int status,
							Bundle extras)
					{

					}
				});

		// publish the extension data update.
		publishUpdate(new ExtensionData()
				.visible(true)
				.icon(R.drawable.ic_launcher)
				.status("Location")
				.expandedTitle(area)
				.expandedBody(fullAddress)
				.contentDescription(
						"This extension displays the current location ")
				.clickIntent(
						new Intent(Intent.ACTION_VIEW, Uri
								.parse("http://maps.google.com"))));
	}

	private String fullAddress = "";
	private String area = "";

}
